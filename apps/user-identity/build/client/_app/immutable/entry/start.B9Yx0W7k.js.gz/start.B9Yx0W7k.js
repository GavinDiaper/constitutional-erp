import{l as o,a as r}from"../chunks/jmA1SyAS.js";export{o as load_css,r as start};
